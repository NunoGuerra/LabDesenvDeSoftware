﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoodleManager___Selenium_Demo_APP
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization;
    using System.Text;
    using OpenQA.Selenium;

    namespace MoodleManager___Selenium_Demo_APP
    {
        [Serializable]
        public class ExceptionLoginMoodleInatingivel : Exception
        {
    
            public ExceptionLoginMoodleInatingivel()
            {
            }

            public ExceptionLoginMoodleInatingivel(string message) : base(message)
            {

            }

            public ExceptionLoginMoodleInatingivel(string message, Exception innerException) : base(message, innerException)
            {

            }

            protected ExceptionLoginMoodleInatingivel(SerializationInfo info, StreamingContext context) : base(info, context)
            {

            }
        }
    }

}
