﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace MoodleManager___Selenium_Demo_APP
{
    public class Mensagem
    {
        public string LoginSucesso() { return "Login Sucesso"; }
        public string LoginInsucesso() { return "Login Insucesso"; }
        public string NaoHaNovasMensagens() { return "Não há novas mensagens";}
        public string ProcurandoNovasMensagens() { return "A procurar novas mensagens em tópicos no Moodle"; }
        public string ASair() { return "Programa a sair..."; }
    }
}
