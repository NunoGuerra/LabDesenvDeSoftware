﻿
namespace MoodleManager___Selenium_Demo_APP
{
    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LogoMoodleManager = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.botaoLogin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.userTextBox = new System.Windows.Forms.TextBox();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.groupBoxLogin = new System.Windows.Forms.GroupBox();
            this.botaoNovasMensagensMoodle = new System.Windows.Forms.Button();
            this.botaoClear = new System.Windows.Forms.Button();
            this.groupBoxFeedback = new System.Windows.Forms.GroupBox();
            this.listBoxFeedback = new System.Windows.Forms.ListBox();
            this.botaoLimpaFeedback = new System.Windows.Forms.Button();
            this.botaoSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.LogoMoodleManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBoxLogin.SuspendLayout();
            this.groupBoxFeedback.SuspendLayout();
            this.SuspendLayout();
            // 
            // LogoMoodleManager
            // 
            this.LogoMoodleManager.Image = global::MoodleManager___Selenium_Demo_APP.Properties.Resources.MoodleManager_app_title_exp;
            this.LogoMoodleManager.Location = new System.Drawing.Point(1, 1);
            this.LogoMoodleManager.Name = "LogoMoodleManager";
            this.LogoMoodleManager.Padding = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.LogoMoodleManager.Size = new System.Drawing.Size(379, 77);
            this.LogoMoodleManager.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoMoodleManager.TabIndex = 0;
            this.LogoMoodleManager.TabStop = false;
            this.LogoMoodleManager.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::MoodleManager___Selenium_Demo_APP.Properties.Resources.Icon_small;
            this.pictureBox2.Location = new System.Drawing.Point(282, 11);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Padding = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.pictureBox2.Size = new System.Drawing.Size(85, 71);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // botaoLogin
            // 
            this.botaoLogin.Location = new System.Drawing.Point(16, 140);
            this.botaoLogin.Name = "botaoLogin";
            this.botaoLogin.Size = new System.Drawing.Size(72, 28);
            this.botaoLogin.TabIndex = 2;
            this.botaoLogin.Text = "LOGIN";
            this.botaoLogin.UseVisualStyleBackColor = true;
            this.botaoLogin.Click += new System.EventHandler(this.botaoLogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "NetID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Password";
            // 
            // userTextBox
            // 
            this.userTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.userTextBox.Location = new System.Drawing.Point(16, 52);
            this.userTextBox.Name = "userTextBox";
            this.userTextBox.Size = new System.Drawing.Size(153, 23);
            this.userTextBox.TabIndex = 5;
            // 
            // passTextBox
            // 
            this.passTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.passTextBox.Location = new System.Drawing.Point(16, 96);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.PasswordChar = '•';
            this.passTextBox.Size = new System.Drawing.Size(153, 23);
            this.passTextBox.TabIndex = 6;
            // 
            // groupBoxLogin
            // 
            this.groupBoxLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.groupBoxLogin.Controls.Add(this.botaoNovasMensagensMoodle);
            this.groupBoxLogin.Controls.Add(this.botaoClear);
            this.groupBoxLogin.Controls.Add(this.pictureBox2);
            this.groupBoxLogin.Controls.Add(this.passTextBox);
            this.groupBoxLogin.Controls.Add(this.botaoLogin);
            this.groupBoxLogin.Controls.Add(this.userTextBox);
            this.groupBoxLogin.Controls.Add(this.label2);
            this.groupBoxLogin.Controls.Add(this.label1);
            this.groupBoxLogin.Location = new System.Drawing.Point(1, 84);
            this.groupBoxLogin.Name = "groupBoxLogin";
            this.groupBoxLogin.Size = new System.Drawing.Size(379, 184);
            this.groupBoxLogin.TabIndex = 7;
            this.groupBoxLogin.TabStop = false;
            this.groupBoxLogin.Text = "Enter your NetID and Password";
            // 
            // botaoNovasMensagensMoodle
            // 
            this.botaoNovasMensagensMoodle.Location = new System.Drawing.Point(185, 88);
            this.botaoNovasMensagensMoodle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.botaoNovasMensagensMoodle.Name = "botaoNovasMensagensMoodle";
            this.botaoNovasMensagensMoodle.Size = new System.Drawing.Size(173, 80);
            this.botaoNovasMensagensMoodle.TabIndex = 8;
            this.botaoNovasMensagensMoodle.Text = "Abrir um separador no Google Chrome para cada tópico com mensagens";
            this.botaoNovasMensagensMoodle.UseVisualStyleBackColor = true;
            this.botaoNovasMensagensMoodle.Click += new System.EventHandler(this.botaoMensagensNovasForum_Click);
            // 
            // botaoClear
            // 
            this.botaoClear.Location = new System.Drawing.Point(94, 140);
            this.botaoClear.Name = "botaoClear";
            this.botaoClear.Size = new System.Drawing.Size(75, 28);
            this.botaoClear.TabIndex = 7;
            this.botaoClear.Text = "CLEAR";
            this.botaoClear.UseVisualStyleBackColor = true;
            this.botaoClear.Click += new System.EventHandler(this.botaoClear_Click);
            // 
            // groupBoxFeedback
            // 
            this.groupBoxFeedback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.groupBoxFeedback.Controls.Add(this.listBoxFeedback);
            this.groupBoxFeedback.Location = new System.Drawing.Point(1, 268);
            this.groupBoxFeedback.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBoxFeedback.Name = "groupBoxFeedback";
            this.groupBoxFeedback.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBoxFeedback.Size = new System.Drawing.Size(379, 251);
            this.groupBoxFeedback.TabIndex = 8;
            this.groupBoxFeedback.TabStop = false;
            this.groupBoxFeedback.Text = "APP Feedback";
            // 
            // listBoxFeedback
            // 
            this.listBoxFeedback.BackColor = System.Drawing.SystemColors.Info;
            this.listBoxFeedback.FormattingEnabled = true;
            this.listBoxFeedback.ItemHeight = 15;
            this.listBoxFeedback.Location = new System.Drawing.Point(5, 16);
            this.listBoxFeedback.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxFeedback.Name = "listBoxFeedback";
            this.listBoxFeedback.Size = new System.Drawing.Size(368, 229);
            this.listBoxFeedback.TabIndex = 0;
            this.listBoxFeedback.SelectedIndexChanged += new System.EventHandler(this.listBoxFeedback_SelectedIndexChanged);
            // 
            // botaoLimpaFeedback
            // 
            this.botaoLimpaFeedback.Location = new System.Drawing.Point(1, 523);
            this.botaoLimpaFeedback.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.botaoLimpaFeedback.Name = "botaoLimpaFeedback";
            this.botaoLimpaFeedback.Size = new System.Drawing.Size(296, 21);
            this.botaoLimpaFeedback.TabIndex = 8;
            this.botaoLimpaFeedback.Text = "Limpar Feedback";
            this.botaoLimpaFeedback.UseVisualStyleBackColor = true;
            this.botaoLimpaFeedback.Click += new System.EventHandler(this.botaoLimpaFeeback_click);
            // 
            // botaoSair
            // 
            this.botaoSair.Location = new System.Drawing.Point(302, 524);
            this.botaoSair.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.botaoSair.Name = "botaoSair";
            this.botaoSair.Size = new System.Drawing.Size(78, 20);
            this.botaoSair.TabIndex = 9;
            this.botaoSair.Text = "Sair";
            this.botaoSair.UseVisualStyleBackColor = true;
            this.botaoSair.Click += new System.EventHandler(this.botaoCliqueSair);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(384, 549);
            this.Controls.Add(this.botaoSair);
            this.Controls.Add(this.groupBoxFeedback);
            this.Controls.Add(this.groupBoxLogin);
            this.Controls.Add(this.botaoLimpaFeedback);
            this.Controls.Add(this.LogoMoodleManager);
            this.MaximumSize = new System.Drawing.Size(400, 588);
            this.MinimumSize = new System.Drawing.Size(400, 588);
            this.Name = "FormMain";
            this.Text = "Moodle Manager";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.LogoMoodleManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBoxLogin.ResumeLayout(false);
            this.groupBoxLogin.PerformLayout();
            this.groupBoxFeedback.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox LogoMoodleManager;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button botaoLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox userTextBox;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.GroupBox groupBoxLogin;
        private System.Windows.Forms.Button botaoClear;
        private System.Windows.Forms.GroupBox groupBoxFeedback;
        private System.Windows.Forms.ListBox listBoxFeedback;
        private System.Windows.Forms.Button botaoLimpaFeedback;
        private System.Windows.Forms.Button botaoNovasMensagensMoodle;
        private System.Windows.Forms.Button botaoSair;
        }
}

