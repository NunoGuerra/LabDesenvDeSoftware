﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace MoodleManager___Selenium_Demo_APP
{
    public partial class FormMain : Form
    {
        
        Mensagem login = new Mensagem();
        // private System.Timers.Timer delayTimer = new System.Timers.Timer();        

        View view;
        public FormMain()
        {
            InitializeComponent();
        }

        public void Encerrar()
        {
            Application.Exit();
        }

        public View View
        {
            get => view;
            set => view = value;
        } 

        private void MainWindow_Load(object sender, EventArgs e)
        {

        }

        private void botaoLogin_Click(object sender, EventArgs e)
        {
            View.ClickEmLogin(sender, e);
        }

        private void botaoClear_Click(object sender, EventArgs e)
        {
            //listBoxFeedback.Items.Add("Botão Clear clicado");
            userTextBox.ResetText();
            passTextBox.ResetText();
        }

        private void botaoMensagensNovasForum_Click(object sender, EventArgs e)
        {
            //listBoxFeedback.Items.Add("Botao Novas Mensagens Moodle");
            view.ClicouEmNovasMensagensMoodle(sender, e);
        }

        private void botaoLimpaFeeback_click(object sender, EventArgs e)
        {
            listBoxFeedback.Items.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e) {

            }

        private void listBoxFeedback_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void imprimeMensagemAEfetuarLogin()
        {
            listBoxFeedback.Items.Add("A EfetuarLogin");
        }

        public void imprimeEstadoLogin(bool logged)
        {
            if (logged)
                listBoxFeedback.Items.Add(login.LoginSucesso());
            else listBoxFeedback.Items.Add(login.LoginInsucesso());
        }


        public void imprimeProcurandoMensagensEmTopicosMoodle(ref Mensagem msg)
        {
            listBoxFeedback.Items.Add(msg.ProcurandoNovasMensagens());
            listBoxFeedback.Items.Add(System.Environment.NewLine);
        }

        public void imprimeInformacaoDosSeparadoresAbertos(ref List<ITopico> separadoresView)
        {
            foreach (Topico t in separadoresView)
            {
                listBoxFeedback.Items.Add("NOVO SEPARADOR ABERTO");
                listBoxFeedback.Items.Add("URL-> " + t.Url);
                listBoxFeedback.Items.Add("Título-> "+t.Titulo);
                listBoxFeedback.Items.Add(System.Environment.NewLine);
                //listBoxFeedback.Items.Add("Número de Mensagens Novas-> "+t.NumMensagens);
            }
        }

        public void imprimeNaoHaNovasMensagens(ref Mensagem msg)
        {
            listBoxFeedback.Items.Add(msg.NaoHaNovasMensagens());
        }

        public void PreencheCredenciais(ref Credenciais credenciaisView)
        { 
            credenciaisView.setUsername(userTextBox.Text); 
            credenciaisView.setPassword(passTextBox.Text);
        }

        /*
        public void ImprimeCredenciaisComoTeste(ref Credenciais credenciaisView)
        {
            listBoxFeedback.Items.Add("Teste a leitura das credenciais da Form de login:");
        }
        */

        private void botaoCliqueSair(object sender, EventArgs e)
        {
           
            DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja sair?", "", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                view.CliqueEmSair(e);
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }
    }
}
