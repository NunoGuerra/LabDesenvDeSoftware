﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using MoodleManager___Selenium_Demo_APP.MoodleManager___Selenium_Demo_APP;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;


namespace MoodleManager___Selenium_Demo_APP
{
    class Controller
    {
        Model model;
        View view;
        ModelLog modelLog;
        bool sair;

       

        public delegate void AtivacaoInterface(object origem);
        public event AtivacaoInterface AtivarInterface;

        public Controller()
        {
            sair = false;
            view = new View(model);
            model = new Model(view);

            modelLog = new ModelLog();
            model.ModelLog = modelLog;

            // Comunicação para logs de erros
            view.PrecisoDeLog += modelLog.SolicitarLog;
            modelLog.NotificarLogAlterado += view.NotificacaoDeLogAlterado;

            // Comunicações da Funcionalidade de Login 
            //Interação com os botões
            view.UtilizadorClicouEmLogin += UtilizadorClicouEmLogin;   // Utilizador inseriu credenciais e requisitou login no moodle View->Controller
            view.UtilizadorClicouEmSair += UtilizadorClicouEmSair;
          
            
              //Delegados da View
            view.PretendoEstadoLogin += model.SolicitarEstadoLogin;   // 
            
            //Delegados do Model
            model.PrecisoDeCredenciais += view.SolicitaCredenciaisDeLogin;
            model.EstadoLoginAlterado += view.AtualizaEstadoLogin;    // Atualiza estado Login Model -> View
            
            // Comunicações da Funcionalidade Novas Mensagens em Tópicos no Moodle
            //Interação com o botão
            view.UtilizadorClicouEmNovasMensagensMoodle += UtilizadorClicouEmNovasMensagensMoodle; // Utilizador  requisitou novas mensagens do forum em novos separadores View -> Controller
            //Delegados da view
            view.PretendoNovasMensagensMoodle += model.SolicitarTopicosComMensagensNovas;
            view.PretendoListaDeSeparadoresAbertos += model.SolicitarListaSeparadoresAbertos;
            //Delegados do Model
            model.NovosSeparadoresAbertos += view.AtualizaSeparadoresForamAbertos;  // Notifica a View que há novas mensagens e separadores foram abertos  model->View
            model.NaoHaNovasMensagens += view.ImprimeNaoHaNovasMensagens;           // Notifica a View que não há novas Mensagens model ->View
     

            // Comunicações da funcionalidade de abrir um Separador por cada tópico com mensagem
        }
        
        private void MoodleInatingivel(string mensagem)
        {
            view.AtivarViewLog();
            model.RegistarLog(mensagem);
        }

        private void LoginMoodleInatingivel(string mensagem)
        {
            view.AtivarViewLog();
            model.RegistarLog(mensagem);
        }

        // Iniciar Aplicação
        public void IniciarAplicacao()
        {
            do
            {
                try
                {
                    view.AtivarInterface();
                }
                catch (ExceptionMoodleInatingivel ex)
                {
                    MoodleInatingivel(ex.Message);
                }
                catch (ExceptionLoginMoodleInatingivel ex)
                {
                    LoginMoodleInatingivel(ex.Message);
                }

            } while (!sair);
        }

        // Efetuar Login no Moodle Controller -> Model
        public void UtilizadorClicouEmLogin(object fonte, System.EventArgs args)
        {
            model.EfetuarLoginNoMoodle();
        }
        
        // Verificar se existem mensagens novas no forum controller ->model
        public void UtilizadorClicouEmNovasMensagensMoodle(object font, System.EventArgs args)
        {
            model.VerificarNovasMensagensMoodle();
        }

        private void UtilizadorClicouEmSair(object sender, EventArgs e)
        {
            sair = true;
            view.Encerrar();
        }
    
    }
}
