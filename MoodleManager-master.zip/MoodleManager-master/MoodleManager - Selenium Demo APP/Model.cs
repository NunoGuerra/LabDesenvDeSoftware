﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using MoodleManager___Selenium_Demo_APP.MoodleManager___Selenium_Demo_APP;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace MoodleManager___Selenium_Demo_APP
{
 
    class Model
    {
       private View view;
       // Definição dos objetos username e password no model
       Credenciais credenciaisModel= new Credenciais();

       private string MoodleLoginUrl = "https://cas2.uab.pt/cas/login?service=https%3A%2F%2Felearning.uab.pt%2Flogin%2Findex.php";
       private string mensagemErro;

       public bool LoggedIn { get; set; }        // Verificador de estado de login

       // Lista com os tópicos que contém novas mensagens, cada um tem url nome e numero de novas mensagens
       List<ITopico> topicos;
       private List<Mensagem> mensagens;

       IWebDriver moodleDriver;

       // Delegados para comunicação com a View
       // Solicita Credenciais de login
       public delegate void SolicitarCredenciaisDeLogin(ref Credenciais credenciaisModel);
       public event SolicitarCredenciaisDeLogin PrecisoDeCredenciais;
        
       // Notifica que o estado de login foi alterado
       public delegate void NotificarEstadoLoginAlterado();
       public event NotificarEstadoLoginAlterado EstadoLoginAlterado;
       
       // Notifica que não existem tópicos com novas mensagens
       public delegate void NotificarNaoHaNovasMensagens();
       public event NotificarNaoHaNovasMensagens NaoHaNovasMensagens;

       // Novos Separadores foram abertos
       public delegate void NotificarNovosSeparadoresAbertos();
       public event NotificarNovosSeparadoresAbertos NovosSeparadoresAbertos;

       ModelLog modelLog;

       public ModelLog ModelLog
       {
           get => modelLog;
           set => modelLog = value;
       }
        public Model(View v)
        {
            view = v;
            // Tópico forçado para teste da Comunicação e mensagens enquanto não estiver implementada a Funcionalidade
            topicos = new List<ITopico>();

        }

        public void RegistarLog(string erro)
        {
            ModelLog.LogErro(erro);
        }

        // Verifica se a página está online gravando a mensagem de erro da exceção em erro
        public bool MoodleEstaVivo()
        {
            WebRequest request = System.Net.WebRequest.Create(MoodleLoginUrl);
            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    return response.StatusCode == HttpStatusCode.OK;
                }
            }
            catch (Exception e)
            {
                mensagemErro = e.GetBaseException().Message;
                return false;
            }
        }

        // Efetuar login no Moodle Model->Model
    public void EfetuarLoginNoMoodle()
    {
        
        if (!MoodleEstaVivo())
            {
                throw new ExceptionMoodleInatingivel(mensagemErro);
            }

            // Definição do driver para o browser a utilizar, escondendo a janela da linhas de comando
            // API efetua Login no Moodle - Na página https://elearning.uab.pt/login/index.php
            var chromeDriverService = ChromeDriverService.CreateDefaultService(); 
            chromeDriverService.HideCommandPromptWindow = true;
            moodleDriver = new ChromeDriver(chromeDriverService, new ChromeOptions());

            // Abre página de login
            moodleDriver.Url= "https://elearning.uab.pt/login/index.php";

        if (moodleDriver.Title != "Sistema Central de Autenticação da Universidade Aberta")
            {
                throw new ExceptionLoginMoodleInatingivel(moodleDriver.Title);
            }

            // Solicita credenciais a View 
            PrecisoDeCredenciais(ref credenciaisModel);
            // API encontra o elemento ID=username e preenche com as credenciais previamente solicitadas a View
            var user = moodleDriver.FindElement(By.Id("username"));
            user.SendKeys(credenciaisModel.getUsername());
            // API encontra o elemento ID=password e preenche com as credenciais previamente solicitadas a View
            var pass = moodleDriver.FindElement(By.Id("password"));
            pass.SendKeys(credenciaisModel.getPassword());
            // API define uma var com o elemento Name="submit" que é o botão da página que submete as credenciais para login
            var botoes = moodleDriver.FindElements(By.Name("submit"));
            var botaoLogin = botoes.FirstOrDefault(e => e.Displayed);
            botaoLogin.Click();
            
            /* API efetua Login no Moodle - Na página https://elearning.uab.pt/login/index.php            *
             * 1 - Encontra - input com id="username" -                                                   *
             * 2 - coloca o nome que o utilizador inseriu em "Utilizador" na APP nesse input da página.   *
             * 3 - Encontra - input com id="password" -                                                   *
             * 4 - coloca a password que o utilizador inseriu em "Password" na APP nesse input da página  *
             * 5 - Encontra - class="btn-submit" com name="submit"                                        */
            ConfirmaSeLoginAceite(moodleDriver);  //Confirmar se Login Foi Aceite Model -> Model
        }

        //Confirmar se Login Foi Aceite Model -> Model
        public void ConfirmaSeLoginAceite(IWebDriver moodleDriver)
        {
            /* Aqui há várias Opções podemos faze-lo de diversas formas sendo que deixo algumas opções               *
             * -------------------  OPÇÕES PARA VERIFICAÇÃO SE O LOGIN FALHOU   ------------------------------------ *
             * 1ª Opção - Podemos verificar a div com id="status" da class="errors", se existir então o login falhou.*
             * 2ª Opção - Se após o clique no "submit" o url atual continuar com https://cas2.uab.pt/cas/login,      *
             *            então o login falhou                                                                       *
             *  Em qualquer uma das opções este método tem que chamar o método de LoginFalha() no caso de alguma se  *
             *  verificar                                                                                            *
             * ------------------  OPÇÕES PARA VERIFICAÇÃO SE O LOGIN FOI ACEITE   --------------------------------- *
             * 1ª Opção - Esta penso que será a que faz mais sentido, veridicar o url após o clique no botão "submit"*
             *            se for https://elearning.uab.pt/my/ então o login foi efetuado com sucesso                 *
             * 2º Opção - Se existir uma class="container navbar" na página atual                                    *
             * Em qualquer uma das opções este método tem que chamar o método de LoginSucesso() caso se verifiquem   *
             *                                                                                                       *
             * é Claro que se se verificar que falhou ou que foi efetuado com sucesso é suficiente, basta um deles   *
             * ser verdade para o outro ser falso, é uma questão a discutir entre nós                                */

            // Loop sobre as janelas abertas do moodleDriver
            foreach (string winHandle in moodleDriver.WindowHandles)
            {
                // Fazer o set do moodledriver para a nova janela aberta(chrome)
                moodleDriver.SwitchTo().Window(winHandle);
            }

            // Confirmar se login foi efectuado com successo por verificacao de URL (https://elearning.uab.pt/my/)
            LoggedIn = moodleDriver.Url == "https://elearning.uab.pt/my/" ? true : false;

            if (!LoggedIn)
                moodleDriver.Close();

            EstadoLoginAlterado();
        }

        public void SolicitarEstadoLogin(ref bool estadoLogin)
        {
            estadoLogin = LoggedIn;
            //Notifica que o Login foi alterado
            
        }

        // Verifica se existem novas mensagens no Moodle
        public void VerificarNovasMensagensMoodle()
        {
            if (!MoodleEstaVivo())
            {
                throw new ExceptionMoodleInatingivel(mensagemErro);
            }

            bool mensagens;
            if (LoggedIn)
            {
                   IList<IWebElement> novasMensagens = moodleDriver.FindElements(By.XPath("//a[@title='Fórum']")); // Topicos de cada UC

                   foreach (IWebElement n in novasMensagens)
                   {
                
                       string Url = n.GetAttribute("href");
                       string Titulo = n.GetAttribute("innerHTML");
                       ITopico t = new Topico(Url, Titulo);

                       topicos.Add(t);
                   }

                if (topicos.Count > 0)
                    mensagens = true;
                else mensagens = false;
                
                if (mensagens) // Se houver 
                    SolicitarTopicosComMensagensNovas();  // Solicita os Tópicos que têm novas mensagens
                else NaoHaNovasMensagens();     // Senao Notifica a view de que não há novas mensagens
            }
        }

        public void SolicitarTopicosComMensagensNovas()
        {
            if (!MoodleEstaVivo())
            {
                throw new ExceptionMoodleInatingivel(mensagemErro);
            }
            // API - Abrir novos separadores no Google Chrome com os Tópicos que contêm novas mensagens
            moodleDriver.Manage().Window.Maximize();
            IJavaScriptExecutor js = (IJavaScriptExecutor)moodleDriver;
            foreach (ITopico t in topicos)
            {
                js.ExecuteScript("window.open('" + t.Url + "')");
            }
            NovosSeparadoresAbertos();
            topicos.Clear();
        }

        public void SolicitarListaSeparadoresAbertos(ref List<ITopico> separadores)
        {
            separadores = new List<ITopico>();
            foreach (ITopico t in topicos)
            {
                ITopico s = new Topico(t.Url, t.Titulo);
                t.CopiaTopico(s);
                separadores.Add(s);
            }

            // Atualizar a lista de Tópicos (Lis<Topico> topicos) abertos e copiar para List<Topico> separadores de modo a View poder imprimilas na caixa de feedback
        }
       


 

       
        
    }
}
