﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using OpenQA.Selenium;

namespace MoodleManager___Selenium_Demo_APP
{
    [Serializable]
    
    public class ExceptionMoodleInatingivel : Exception
    {
        
        public ExceptionMoodleInatingivel()
        {
        }
        public ExceptionMoodleInatingivel(string message) : base(message)
        {

        }

        public ExceptionMoodleInatingivel(string message, Exception innerException) : base(message, innerException)
        {

        }

        protected ExceptionMoodleInatingivel(SerializationInfo info, StreamingContext context) : base(info, context)
        {

        }
    }
}
