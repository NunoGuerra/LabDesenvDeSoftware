﻿using System;
using System.Windows.Forms;
using MoodleManager___Selenium_Demo_APP;

namespace MoodleManager___Selenium_Demo_APP
{
    public class ViewLog
    {
        FormLog formLog;
        Form pai;

        public ViewLog(Form origem)
        {
            pai = origem;
        }

        internal void AtivarViewLog()
        {
            if (formLog == null) formLog = new FormLog();
        }
        internal void AlterarLog(string log)
        {
            if (formLog == null)
                return;
            formLog.EscreverLog(log);
            formLog.ShowDialog(pai);
        }
    }
}
