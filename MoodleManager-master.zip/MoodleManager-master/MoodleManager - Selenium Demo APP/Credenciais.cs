﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoodleManager___Selenium_Demo_APP
{
    public class Credenciais
    {
        private string username;
        private string password;
        public void setUsername(string user) { username = user; }
        public void setPassword(string pass) { password = pass; }
        public string getUsername() { return username; }
        public string getPassword() { return password; }
    }
}
