﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoodleManager___Selenium_Demo_APP
{
    //Classe Tópico que receberá os dados relativos a cada tópico com mensagens

    public interface ITopico
    {
        string Url { get; set; }
        string Titulo { get; set; }

        // Método que efetua cópia de um tópico
        public void CopiaTopico(ITopico t)
        {
            t.Titulo = Titulo;
            t.Url = Url;
        }

    }
    public class Topico : ITopico
    {
        private string url;
        private string titulo;
        public string Url { get => url; set => url = value; }
        public string Titulo { get => titulo; set => titulo = value; }

        public Topico(string u, string t)
        {
            Url = u;
            Titulo = t;
        }


    }
}
