﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MoodleManager___Selenium_Demo_APP
{
    public partial class FormLog : Form
    {
        public FormLog()
        {
            InitializeComponent();
        }

        public void EscreverLog(string log)
        {
            textBoxLog.Text = log;
        }

        private void textBoxLog_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
