﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace MoodleManager___Selenium_Demo_APP
{
    public class View
    {
        private Model model;
        private FormMain janela;
        private ViewLog viewlog;

        Credenciais credenciaisView = new Credenciais();

        // cópia de loggedin da view
        private bool estadoLoggedInView;

        // cópia de Lista de tópicos abertos
        private List<ITopico> topicosView;

        Mensagem mensagem = new Mensagem();

        public event System.EventHandler UtilizadorClicouEmLogin;
        //public event System.EventHandler UtilizadorClicouEmClear;
        public event System.EventHandler UtilizadorClicouEmNovasMensagensMoodle;

        public event EventHandler UtilizadorClicouEmSair;
     
        //Delegado que Solicita o Estado do Login
        public delegate void SolicitacaoEstadoDeLogin(ref bool estadoLogin);
        public event SolicitacaoEstadoDeLogin PretendoEstadoLogin;

        //Delegado que Solicita a procura de novas Mensagens do Moodle
        public delegate void SolicitacaoDeNovasMensagensMoodle();
        public event SolicitacaoDeNovasMensagensMoodle PretendoNovasMensagensMoodle;

        //Delegado que Solicita a lista de Novos separadores
        public delegate void SolicitacaoDeSeparadoresAbertos(ref List<ITopico> separadores);
        public event SolicitacaoDeSeparadoresAbertos PretendoListaDeSeparadoresAbertos;

        public delegate string SolicitacaoLog();
        public event SolicitacaoLog PrecisoDeLog;

        internal View(Model m)
        {
            model = m;
            viewlog = new ViewLog(janela);
        }

        // Iniciar Interface desenhar Janelas, botões e caizas de texto
        public void AtivarInterface()
        {
            janela = new FormMain
            {
                View = this
            };
            janela.ShowDialog();
        }
            
        public void Encerrar()
        {
            janela.Encerrar();
        }

        public void AtivarViewLog()
        {
            viewlog.AtivarViewLog();
        }

        public void NotificacaoDeLogAlterado()
        {
            viewlog.AlterarLog(PrecisoDeLog());
        }

        public void SolicitaCredenciaisDeLogin(ref Credenciais credenciaisModel)
        {
            credenciaisModel = new Credenciais();
            credenciaisModel = credenciaisView;
        }

        public void AtualizaEstadoLogin()
        {
            
           // Atualizar o estado de login recebido do Model na janela de feedback
           // Se estado do Login for False chama Envia mensagem de Falha no login 
           // se estado do Login for True chama redesenha janela sem campos para login e envia mensagem de login sucesso
           PretendoEstadoLogin(ref estadoLoggedInView);
           ImprimeEstadoLogin();
        }

        public void LimpaCredenciais()
        {
            // Limpa os campos das credenciais de login, userTextBox e passTextBox
        }

        // Evento botao de login Clicado
        public void ClickEmLogin(object origem, EventArgs e)
        {
            ImprimeAEfetuarlogin();                 // Envia Mensagem a Efetuar Login
            GuardaCredenciais();                    // Método que Lê as credenciais do From de Login e guarda em CredenciaisView
            UtilizadorClicouEmLogin(origem,e);      // Evento Utilizador clicou em Login e inseriu as credenciais 
        }

        // evento botao de clear clicado
        public void ClickEmClear(object origem, EventArgs e)
        {
            LimpaCredenciais(); // Limpa credenciais do forms
        }
        

        public void ClicouEmNovasMensagensMoodle(object origem, EventArgs e)
        {
            ImprimeVerificandoNovasMensagensMoodle();
            UtilizadorClicouEmNovasMensagensMoodle(origem, e);
        }

        public void AtualizaSeparadoresForamAbertos()
        {
            PretendoListaDeSeparadoresAbertos(ref topicosView);
            ImprimeSeparadoresAbertos();

        }

        // Manda imprimir a mensagem A efetuar Login   View -> Forms
        public void ImprimeAEfetuarlogin()
        {
            janela.imprimeMensagemAEfetuarLogin();
        }

        public void ImprimeEstadoLogin()
        {
            janela.imprimeEstadoLogin(estadoLoggedInView);
        }


        public void ImprimeVerificandoNovasMensagensMoodle()
        {
            janela.imprimeProcurandoMensagensEmTopicosMoodle(ref mensagem );
        }

        public void ImprimeSeparadoresAbertos()
        {
            janela.imprimeInformacaoDosSeparadoresAbertos(ref topicosView);
        }

        private void GuardaCredenciais()
        {
            janela.PreencheCredenciais(ref credenciaisView);

            //TesteCredenciais(ref credenciaisView);
        }

        /*
        public void TesteCredenciais(ref Credenciais credenciais)
        {
           janela.ImprimeCredenciaisComoTeste(ref credenciais);
        }
        */
        public void ImprimeNaoHaNovasMensagens()
        {
            janela.imprimeNaoHaNovasMensagens(ref mensagem);
        }

        public void CliqueEmSair(EventArgs e)
        {
            UtilizadorClicouEmSair(this, e);
        }


    }
}
