﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace MoodleManager___Selenium_Demo_APP
{
    class ModelLog
    {
        public delegate void NotificacaoLogAlterado();
        public event NotificacaoLogAlterado NotificarLogAlterado;

        private string log;

        public ModelLog()
        {
            log = "";
        }

        public void LogErro(string mensagem)
        {
            
               // log += "O MoodleManager não consegue aceder ao Moodle da Universidade Aberta, verifique a sua ligação de internet" + System.Environment.NewLine;
               log += "O Programa devolveu o seguinte erro: " + mensagem + System.Environment.NewLine;
               if (mensagem == "Este anfitrião não é conhecido.")
               {
                   log += "    ->Este erro pode dever-se a uma falha na internet, verifique a sua ligação.";
               } else if (mensagem == "O sítio está em manutenção e não está de momento disponível") 
               {
                    log += "    ->O Moodle da Universidade Aberta está em manutenção tente mais tarde" + System.Environment.NewLine;
               }
               else
               {
                   log += "    ->Por motivos não identificados o programa não consegue aceder á página de login do Moodle da Universidade Aberta" + System.Environment.NewLine;
               }

            NotificarLogAlterado();
        }

        public string SolicitarLog()
        {
            return log;
        }
    }
}
