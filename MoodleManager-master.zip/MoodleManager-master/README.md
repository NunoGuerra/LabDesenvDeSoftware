# MoodleManager

Obsolete since Moodle update
